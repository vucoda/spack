Thank you for the support.

### [2019.12/2021.9] [Chan-Zuckerberg Foundation EOSS Initiative](https://chanzuckerberg.com/eoss/)

Between December 2019 and September 2021, development and maintaining of OpenBLAS was funded in part by the Chan-Zuckerberg Foundation in the context of  two grants awarded to the NumPy Foundation and managed by NumFocus (Cycles 1 and 3 of the Essential Open Source Software for Science (EOSS) Initiative of the Chan-Zuckerberg Foundation)  

### [2013.8] [Testbed for OpenBLAS project](https://www.bountysource.com/fundraisers/443-testbed-for-openblas-project)

https://www.bountysource.com/fundraisers/443-testbed-for-openblas-project/pledges

In chronological order:

* aeberspaecher
* fmolina
* saullocastro
* xianyi
* cuda
* carter
* StefanKarpinski
* staticfloat
* sebastien-villemot
* JeffBezanson
* ihnorton
* simonp0420
* andrioni
* Tim Holy
* ivarne
* johnmyleswhite
* traz
* Jean-Francis Roy
* bkalpert
* Anirban
* pgermain
* alexandre.lacoste.18
* foges
* ssam
* WestleyArgentum
* daniebmariani
* pjpuglia
* albarrentine
* Alexander Vogt


