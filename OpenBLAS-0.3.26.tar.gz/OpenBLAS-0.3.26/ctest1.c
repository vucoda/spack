int hogehoge(void){return 0;}
