To run these tests is necessary some manuall input (most of then not supported by QTest[1]),
because of that this is not part of automatic test context.


[1]http://bugreports.qt.nokia.com/browse/QTBUG-13397
