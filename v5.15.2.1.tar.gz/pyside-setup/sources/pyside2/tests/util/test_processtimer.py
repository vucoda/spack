#############################################################################
##
## Copyright (C) 2016 The Qt Company Ltd.
## Contact: https://www.qt.io/licensing/
##
## This file is part of the test suite of Qt for Python.
##
## $QT_BEGIN_LICENSE:GPL-EXCEPT$
## Commercial License Usage
## Licensees holding valid commercial Qt licenses may use this file in
## accordance with the commercial license agreement provided with the
## Software or, alternatively, in accordance with the terms contained in
## a written agreement between you and The Qt Company. For licensing terms
## and conditions see https://www.qt.io/terms-conditions. For further
## information use the contact form at https://www.qt.io/contact-us.
##
## GNU General Public License Usage
## Alternatively, this file may be used under the terms of the GNU
## General Public License version 3 as published by the Free Software
## Foundation with exceptions as appearing in the file LICENSE.GPL3-EXCEPT
## included in the packaging of this file. Please review the following
## information to ensure the GNU General Public License requirements will
## be met: https://www.gnu.org/licenses/gpl-3.0.html.
##
## $QT_END_LICENSE$
##
#############################################################################

'Tests for processtimer.py'

import unittest
import os

from subprocess import Popen, PIPE
from processtimer import TimeoutException, ProcessTimer

class TimeoutTest(unittest.TestCase):

    def tearDown(self):
        try:
            os.kill(self.proc.pid, 9)
        except OSError:
            pass

    def testRaise(self):
        self.proc = Popen(['python2.5', '-c', 'while True: pass' ], stdout=PIPE, stderr=PIPE)
        timer = ProcessTimer(self.proc, 1)
        self.assertRaises(TimeoutException, timer.waitfor)

class SimpleTest(unittest.TestCase):

    def tearDown(self):
        try:
            os.kill(self.proc.pid, 9)
        except OSError:
            pass
    def testSimple(self):
        self.proc = Popen(['python2.5', '-c', '"print"'], stdout=PIPE, stderr=PIPE)
        timer = ProcessTimer(self.proc, 10)
        timer.waitfor()

class TestEchoOutput(unittest.TestCase):

    def tearDown(self):
        try:
            os.kill(self.proc.pid, 9)
        except OSError:
            pass

    def testOutput(self):
        self.proc = Popen(['python2.5', '-c', 'print 1',], stdout=PIPE, stderr=PIPE)
        timer = ProcessTimer(self.proc, 1)
        timer.waitfor()
        self.assertEqual(self.proc.stdout.read().strip(), '1')

class TestRetCode(unittest.TestCase):

    def tearDown(self):
        try:
            os.kill(self.proc.pid, 9)
        except OSError:
            pass

    def testSimple(self):
        self.proc = Popen(['python2.5', '-c', 'print 1'], stdout=PIPE, stderr=PIPE)
        timer = ProcessTimer(self.proc, 10)
        timer.waitfor()

        self.assertEqual(self.proc.poll(), 0)


if __name__ == '__main__':
    unittest.main()
