
from PyQt4.QtXmlPatterns import *
