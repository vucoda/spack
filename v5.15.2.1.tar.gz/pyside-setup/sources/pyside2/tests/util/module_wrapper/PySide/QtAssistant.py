
from PyQt4.QtAssistant import *
