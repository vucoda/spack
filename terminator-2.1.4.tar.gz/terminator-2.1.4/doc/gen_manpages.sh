#!/bin/sh

asciidoctor -b manpage terminator.adoc
asciidoctor -b manpage terminator_config.adoc
