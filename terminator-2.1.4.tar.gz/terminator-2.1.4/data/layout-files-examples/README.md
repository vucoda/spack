The JSONs files in this directory are example config files used by `--config-json` option.

Once this feature would be documented officially this directory can be removed.

Example:
```
./terminator --config-json data/layout-files-examples/2-3-grid.json
```
