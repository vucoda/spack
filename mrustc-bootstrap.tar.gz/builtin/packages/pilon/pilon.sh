#!/bin/sh
# convenience wrapper for the pilon jar file
java -jar pilon.jar "$@"
