#!/bin/sh
# convenience wrapper for the chexmix jar file
java -jar chexmix.jar "$@"
